{
	"lang": {
		"en_US": {                                                                
		    "Searches": "searches",                                                                        
	    	"BasicGeoCodeError": "Unknown basic Geocode ({0}). Change it back!",                            
	    	"GeoCodeError": "Unknown Geocode ({0}). Leave blank to use default Geocode ({1}).",               
	    	"Daily": "Top {0} searches on Google in last 24H:",                                             
	    	"NoKeyWords": "No keyword!",                                                                     
	    	"RelatedTopics": "Top {0} hot topics related to keyword '{1}' on Google in last 24H:",           
	    	"RealTimeTrends": "Top {0} realtime trends on Google in last 24H:"                             
	    },                                                                                                  
	    "vi_VN": {                                                                                           
	    	"Searches": "lượt tìm kiếm",                                                                  
	    	"BasicGeoCodeError": "Mã basic Geocode ({0}) không tồn tại. hãy chỉnh lại!",                     
	    	"GeoCodeError": "Mã Geocode không tồn tại ({0}). Để trống để sử dụng mã GeoCode mặc định ({1}).",
	    	"Daily": "Top {0} tìm kiếm được tìm nhiều nhất trên Google trong 24H qua:",                     
	    	"NoKeyWords": "Không có từ khóa!",                                                       
	    	"RelatedTopics": "Top {0} chủ đề nóng dựa theo từ khóa '{1}' trên Google trong 24H qua:",
	    	"RealTimeTrends": "top {0} những trào lưu hot hiện tại theo thời gian thực Trên Google:" 
	    }
    },
	"langdes": {
		"Searches": [],
	    "BasicGeoCodeError": ["{0}"],
	    "GeoCodeError": ["{0}","{1}"],
		"Daily": ["{0}"],
		"NoKeyWords": [],
		"RelatedTopics": ["{0}","{1}"],
		"RealTimeTrends": ["{0}"]
	}
}
