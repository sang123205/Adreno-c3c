{
	"config": {
		"DailyBasicGeocode": "VN",
		"DailyLimitSearches": "15",
		"RelatedTopicsBasicGeocode": "VN",
		"RelatedTopicsLimitSearch": "5",
		"RealtimeTrendsbasicGeocode": "VN",
		"RealtimeTrendsLimitSearch": "10"
	},
	"configdes": {
    	"DailyBasicGeocode": [true, false, false, false],
		"DailyLimitSearches": [false, false, 16, 0],
		"RelatedTopicsBasicGeocode": [true, false, false, false],
		"RelatedTopicsLimitSearch": [false, false, 15, 0],
		"RealtimeTrendsbasicGeocode": [true, false, false, false],
		"RealtimeTrendsLimitSearch": [false, false, 15, 0]
	}
}