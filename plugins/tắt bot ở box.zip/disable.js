var wait = global.nodemodule["wait-for-stuff"];

!Array.isArray(global.data.disabledThread) ? global.data.disabledThread = [] : "";
var disable = function (type, data) {
	if (type != "Facebook") {
        return {
            data: "THIS COMMAND IS NOT EXECUTABLE IN THIS PLATFORM!",
            handler: "internal"
        }
    }
    var threadID = data.msgdata.threadID;
    var allowRun = false;
    if (!data.admin) {
        var [err, threadInfo] = wait.for.function(data.facebookapi.getThreadInfo, data.msgdata.threadID);
        var adminIDs = threadInfo.adminIDs.map(x => x.id.toString());
        data.log("[INTERNAL]", "Got AdminIDs of thread", data.msgdata.threadID, ":", adminIDs);
        if (adminIDs.indexOf(data.msgdata.senderID) != -1) {
            allowRun = true;
        }
    } else {
        allowRun = true;
    }
	if (allowRun) {
		if (global.data.disabledThread.indexOf(data.msgdata.threadID) == -1) {
			global.data.disabledThread.push(data.msgdata.threadID);
			return {
				handler: "internal",
				data: `Bot đã bị admin đẹp zai tắt UwU`
			}
		}
	}
}

var chathook = function (type, data) {
	var message = data.msgdata;
	if (message.type == "message") {
		var args = message.body
			.replace((/”/g), "\"")
			.replace((/“/g), "\"")
			.split(/((?:"[^"\\]*(?:\\[\S\s][^"\\]*)*"|'[^'\\]*(?:\\[\S\s][^'\\]*)*'|\/[^/\\]*(?:\\[\S\s][^/\\]*)*\/[gimy]*(?=\s|$)|(?:\\\s|\S))+)(?=\s|$)/)
			.filter(function (el) {
				return !(el == null || el == "" || el == " ");
			});
		args = args.map(xy => xy.replace(/["]/g, ""));
		if (message.body.startsWith(global.config.commandPrefix) && global.data.disabledThread.indexOf(data.msgdata.threadID) != -1) {
			if (args[0].substr(1) != "tridungdeptroai") {
				data.return({
					handler: "internal",
					data: `Bot đã bị tắt, không chỉ cách mở đâu liu liu :P`
				});
				return true;
			} else {
				global.data.disabledThread.splice(global.data.disabledThread.indexOf(data.msgdata.threadID), 1);
				data.return({
					handler: "internal",
					data: "Bot Đã Được Dũng Đẹp Troai Bật Lên Lại"
				});
			}
		} else {
			return false;
		}
	}
}

module.exports = {
	disable,
	chathook
}