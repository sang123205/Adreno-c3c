var fetch = global.nodemodule["node-fetch"];

var cc_get = function cc_get(type, data) {
	(async function () {
		var returntext = `Từ điển việt nam\nCác nghĩa của từ cc\n1. cc dùng để chỉ đồ vật\nVD: cái chén\n2.cc dùng để chỉ động vật\nVD : con cá\n3. cc dùng để chỉ thứ quý giá của đàn ông\nVD : con cặc\n4. cc dùng để ám chỉ báo hiểu cần sự trợ giúp\nVD : cua cạp\n5. cc dùng để bộc lộ cảm súc\nVD : cau có\n6. cc dùng để báo hiệu cho người khác làm gì đó\nVD : cánh cửa\nCảm ơn bạn đã sử dụng từ điển ^^`;
		return {
			handler: "internal",
			data: returntext
		}
	})().then(function (returndata) {
		data.return(returndata);
	});
} 

module.exports = {
	cc_get: cc_get
}